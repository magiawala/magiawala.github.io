const navbar = document.querySelector('.navbar');
const scrollBtn = document.getElementById('scroll-btn');
let lastScrollY = window.scrollY;

// Scroll Handler
window.addEventListener('scroll', () => {
    const currentScrollY = window.scrollY;

    // Header Logic: Hide on scroll down, show on scroll up
    // BUT keep visible if mobile menu is open
    const isMenuOpen = mobileMenu && mobileMenu.classList.contains('active');

    if (currentScrollY > lastScrollY && currentScrollY > 50 && !isMenuOpen) {
        navbar.classList.add('nav-hidden');
    } else {
        navbar.classList.remove('nav-hidden');
    }

    // Button Logic: "Down" at top, "Up" when scrolled
    if (currentScrollY > 100) {
        scrollBtn.classList.add('up-mode');
    } else {
        scrollBtn.classList.remove('up-mode');
    }

    lastScrollY = currentScrollY;
});

// Hamburger Menu Logic
const hamburger = document.querySelector('.hamburger');
const mobileMenu = document.querySelector('.mobile-menu-overlay');

function closeMenu() {
    hamburger.classList.remove('active');
    mobileMenu.classList.remove('active');
    document.body.style.overflow = 'auto';
}

hamburger.addEventListener('click', () => {
    hamburger.classList.toggle('active');
    mobileMenu.classList.toggle('active');

    // Toggle body scroll
    document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : 'auto';
});

// Close menu when a link is clicked
document.querySelectorAll('.mobile-menu-overlay a').forEach(link => {
    link.addEventListener('click', closeMenu);
});

// Button Click Handler
scrollBtn.addEventListener('click', () => {
    if (scrollBtn.classList.contains('up-mode')) {
        // Go to Top
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    } else {
        // Go to first section (Work)
        document.querySelector('#work').scrollIntoView({
            behavior: 'smooth'
        });
    }
});
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});
